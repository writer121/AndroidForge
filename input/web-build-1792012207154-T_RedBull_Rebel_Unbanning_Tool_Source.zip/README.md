# T~REDBULL X REBEL Unbanning Tool

Android Studio source project. It uses the supplied image as the app's in-app logo and includes a dark red/blue animated neon-inspired interface, country-code selection, phone number validation, several appeal languages, and a Gmail intent with a prefilled appeal.

## Build the APK
1. Install Android Studio (recent stable version) on a computer.
2. Open this folder as a project.
3. Allow Gradle sync to complete (internet is needed for Gradle dependencies).
4. Choose **Build > Build APK(s)**.
5. Find the APK under `app/build/outputs/apk/debug/`.

## Notes
- This is a source project, not a prebuilt APK.
- Country list is a practical starter list, not every country/territory. Add more entries to `countries` and `codes` in `MainActivity.kt` as needed.
- Included appeal languages: English, Urdu, Hindi, Arabic, Spanish, French, Portuguese, Indonesian. Untranslated language options are not shown.
- Gmail/email opens with a draft; the user must review and press Send. The app cannot guarantee WhatsApp account restoration.
- Verify the correct official WhatsApp support contact before sending.
