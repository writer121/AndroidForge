package com.redbull.rebel

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.content.ActivityNotFoundException
import android.net.Uri
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.AlphaAnimation
import android.view.animation.Animation
import android.widget.*
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var country: Spinner
    private lateinit var phone: EditText
    private lateinit var language: Spinner
    private lateinit var status: TextView

    private val countries = listOf(
        "Pakistan (+92)", "India (+91)", "United States (+1)", "United Kingdom (+44)",
        "Saudi Arabia (+966)", "United Arab Emirates (+971)", "Bangladesh (+880)",
        "Afghanistan (+93)", "Turkey (+90)", "Indonesia (+62)", "Malaysia (+60)",
        "Nigeria (+234)", "South Africa (+27)", "Egypt (+20)", "Germany (+49)",
        "France (+33)", "Italy (+39)", "Spain (+34)", "Canada (+1)", "Australia (+61)",
        "Philippines (+63)", "Sri Lanka (+94)", "Nepal (+977)", "Qatar (+974)",
        "Kuwait (+965)", "Oman (+968)", "Bahrain (+973)", "Iraq (+964)",
        "Iran (+98)", "China (+86)", "Japan (+81)", "South Korea (+82)",
        "Brazil (+55)", "Mexico (+52)", "Kenya (+254)", "Ghana (+233)",
        "Morocco (+212)", "Netherlands (+31)", "Sweden (+46)", "Norway (+47)",
        "New Zealand (+64)", "Russia (+7)", "Ukraine (+380)", "Ireland (+353)",
        "Singapore (+65)", "Thailand (+66)", "Vietnam (+84)"
    )
    private val codes = mapOf(
        "Pakistan (+92)" to "+92", "India (+91)" to "+91", "United States (+1)" to "+1",
        "United Kingdom (+44)" to "+44", "Saudi Arabia (+966)" to "+966",
        "United Arab Emirates (+971)" to "+971", "Bangladesh (+880)" to "+880",
        "Afghanistan (+93)" to "+93", "Turkey (+90)" to "+90", "Indonesia (+62)" to "+62",
        "Malaysia (+60)" to "+60", "Nigeria (+234)" to "+234", "South Africa (+27)" to "+27",
        "Egypt (+20)" to "+20", "Germany (+49)" to "+49", "France (+33)" to "+33",
        "Italy (+39)" to "+39", "Spain (+34)" to "+34", "Canada (+1)" to "+1",
        "Australia (+61)" to "+61", "Philippines (+63)" to "+63", "Sri Lanka (+94)" to "+94",
        "Nepal (+977)" to "+977", "Qatar (+974)" to "+974", "Kuwait (+965)" to "+965",
        "Oman (+968)" to "+968", "Bahrain (+973)" to "+973", "Iraq (+964)" to "+964",
        "Iran (+98)" to "+98", "China (+86)" to "+86", "Japan (+81)" to "+81",
        "South Korea (+82)" to "+82", "Brazil (+55)" to "+55", "Mexico (+52)" to "+52",
        "Kenya (+254)" to "+254", "Ghana (+233)" to "+233", "Morocco (+212)" to "+212",
        "Netherlands (+31)" to "+31", "Sweden (+46)" to "+46", "Norway (+47)" to "+47",
        "New Zealand (+64)" to "+64", "Russia (+7)" to "+7", "Ukraine (+380)" to "+380",
        "Ireland (+353)" to "+353", "Singapore (+65)" to "+65", "Thailand (+66)" to "+66",
        "Vietnam (+84)" to "+84"
    )
    private val languages = listOf("English", "Urdu", "Hindi", "Arabic", "Spanish", "French", "Portuguese", "Indonesian")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(8, 8, 14)
        window.navigationBarColor = Color.rgb(8, 8, 14)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 22, 24, 28)
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(13, 4, 12), Color.rgb(4, 9, 24), Color.BLACK)
            )
        }
        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)

        val title = TextView(this).apply {
            text = "𝐓~𝐑𝐄𝐃𝐁𝐔𝐋𝐋 𝐗 𝐑𝐄𝐁𝐄𝐋"
            textSize = 24f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setShadowLayer(14f, 0f, 0f, Color.RED)
        }
        root.addView(title, matchWrap())
        val sub = TextView(this).apply {
            text = "UNBANNING TOOL  •  APPEAL ASSISTANT"
            textSize = 12f
            setTextColor(Color.rgb(70, 190, 255))
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 18)
        }
        root.addView(sub, matchWrap())

        val logo = ImageView(this).apply {
            setImageResource(com.redbull.rebel.R.drawable.app_dp)
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = outline(Color.RED)
            clipToOutline = true
            val pulse = AlphaAnimation(0.82f, 1f).apply {
                duration = 1100
                repeatMode = Animation.REVERSE
                repeatCount = Animation.INFINITE
            }
            startAnimation(pulse)
        }
        val logoParams = LinearLayout.LayoutParams(210, 210)
        logoParams.gravity = Gravity.CENTER
        logoParams.bottomMargin = 18
        root.addView(logo, logoParams)

        addLabel(root, "SELECT COUNTRY / COUNTRY CODE")
        country = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, countries)
            setPadding(10, 8, 10, 8)
        }
        root.addView(country, matchWrap())

        addLabel(root, "WHATSAPP NUMBER")
        phone = EditText(this).apply {
            hint = "Enter number without leading 0"
            textSize = 16f
            setTextColor(Color.WHITE)
            setHintTextColor(Color.LTGRAY)
            inputType = 3
            setSingleLine(true)
            background = outline(Color.rgb(0, 170, 255))
            setPadding(16, 12, 16, 12)
        }
        root.addView(phone, matchWrap())

        addLabel(root, "APPEAL LANGUAGE")
        language = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, languages)
        }
        root.addView(language, matchWrap())

        val button = Button(this).apply {
            text = "OPEN GMAIL  ✉"
            isAllCaps = false
            textSize = 16f
            setTextColor(Color.WHITE)
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(Color.rgb(220, 20, 45), Color.rgb(0, 120, 255))
            ).apply { cornerRadius = 24f }
            setOnClickListener { openAppeal() }
        }
        val bp = matchWrap()
        bp.topMargin = 22
        root.addView(button, bp)

        status = TextView(this).apply {
            text = "Email will be prepared for you to review and send."
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(Color.LTGRAY)
            setPadding(0, 18, 0, 4)
        }
        root.addView(status, matchWrap())
    }

    private fun addLabel(parent: LinearLayout, text: String) {
        parent.addView(TextView(this).apply {
            this.text = text
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(255, 80, 90))
            setPadding(2, 14, 2, 6)
        }, matchWrap())
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun outline(color: Int) = GradientDrawable().apply {
        setColor(Color.rgb(24, 25, 36))
        cornerRadius = 18f
        setStroke(2, color)
    }

    private fun openAppeal() {
        val local = phone.text.toString().trim().replace(Regex("[\\s()-]"), "")
        if (!local.matches(Regex("[0-9]{5,14}")) || local.startsWith("0")) {
            phone.error = "Enter number without the leading zero"
            return
        }
        val fullNumber = (codes[country.selectedItem.toString()] ?: "+92") + local
        val lang = language.selectedItem.toString()
        val subject = when (lang) {
            "Urdu" -> "WhatsApp account restriction review request"
            "Hindi" -> "WhatsApp account restriction review request"
            "Arabic" -> "طلب مراجعة تقييد حساب واتساب"
            "Spanish" -> "Solicitud de revisión de cuenta de WhatsApp"
            "French" -> "Demande de réexamen du compte WhatsApp"
            "Portuguese" -> "Pedido de revisão da conta do WhatsApp"
            "Indonesian" -> "Permintaan peninjauan akun WhatsApp"
            else -> "Request to Review WhatsApp Account Restriction"
        }
        val body = when (lang) {
            "Urdu" -> """السلام علیکم WhatsApp Support،
میں اپنے WhatsApp اکاؤنٹ پر پابندی کا جائزہ لینے کی درخواست کرتا/کرتی ہوں۔
میرا فون نمبر: $fullNumber
براہِ کرم میرے اکاؤنٹ کا جائزہ لیں اور اگر پابندی غلطی سے لگی ہے تو رہنمائی فرمائیں۔
شکریہ۔"""
            "Hindi" -> """नमस्ते WhatsApp Support,
मैं अपने WhatsApp खाते पर लगी पाबंदी की समीक्षा का अनुरोध करता/करती हूँ।
मेरा फ़ोन नंबर: $fullNumber
कृपया मेरे खाते की समीक्षा करें और यदि पाबंदी गलती से लगी है तो मुझे बताएं।
धन्यवाद।"""
            "Arabic" -> """مرحبًا بفريق دعم واتساب،
أرجو مراجعة التقييد المفروض على حسابي.
رقم هاتفي: $fullNumber
يرجى مراجعة الحساب وإبلاغي إذا كان التقييد قد حدث عن طريق الخطأ.
شكرًا لكم."""
            "Spanish" -> """Hola, equipo de soporte de WhatsApp:
Solicito amablemente una revisión de la restricción de mi cuenta.
Mi número de teléfono es: $fullNumber
Por favor, revisen mi cuenta e indíquenme si la restricción se aplicó por error.
Gracias."""
            "French" -> """Bonjour l’équipe d’assistance WhatsApp,
Je demande respectueusement un examen de la restriction de mon compte.
Mon numéro de téléphone : $fullNumber
Merci de vérifier mon compte et de m’indiquer si la restriction a été appliquée par erreur.
Cordialement."""
            "Portuguese" -> """Olá, equipe de suporte do WhatsApp,
Gostaria de solicitar uma análise da restrição da minha conta.
Meu número de telefone: $fullNumber
Por favor, analisem minha conta e informem se a restrição foi aplicada por engano.
Obrigado(a)."""
            "Indonesian" -> """Halo Tim Dukungan WhatsApp,
Saya ingin meminta peninjauan atas pembatasan akun saya.
Nomor telepon saya: $fullNumber
Mohon tinjau akun saya dan beri tahu jika pembatasan ini terjadi karena kesalahan.
Terima kasih."""
            else -> """Hello WhatsApp Support,

I would like to request a review of the restriction on my WhatsApp account.
My phone number (including country code) is: $fullNumber

If this restriction was applied by mistake, please review my account and let me know whether it can be restored. I will follow WhatsApp's Terms of Service.

Thank you for your time."""
        }

        val intent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("mailto:support@whatsapp.com")
            putExtra(Intent.EXTRA_SUBJECT, subject)
            putExtra(Intent.EXTRA_TEXT, body)
            setPackage("com.google.android.gm")
        }
        try {
            startActivity(intent)
            status.text = "Gmail opened. Review the appeal, then tap Send."
        } catch (e: ActivityNotFoundException) {
            val fallback = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("mailto:support@whatsapp.com")
                putExtra(Intent.EXTRA_SUBJECT, subject)
                putExtra(Intent.EXTRA_TEXT, body)
            }
            try {
                startActivity(Intent.createChooser(fallback, "Choose email app"))
            } catch (_: ActivityNotFoundException) {
                Toast.makeText(this, "No email app found. Please install Gmail.", Toast.LENGTH_LONG).show()
            }
        }
    }
}
